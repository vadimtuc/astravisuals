package ru.astravisual.mixin;

import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.astravisual.module.ModuleManager;

@Mixin(class_757.class)
public class GameRendererMixin {

    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void astravisual$noHurtCam(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        if (ModuleManager.NO_HURT_CAM != null && ModuleManager.NO_HURT_CAM.isEnabled()) {
            ci.cancel();
        }
    }
}
