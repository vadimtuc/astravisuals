package ru.astravisual.mixin;

import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.astravisual.module.ModuleManager;

@Mixin(class_329.class)
public class InGameHudMixin {

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void astravisual$hideVanillaCrosshair(class_332 context, class_9779 tickCounter,
                                                CallbackInfo ci) {
        if (ModuleManager.CROSSHAIR != null && ModuleManager.CROSSHAIR.isEnabled()) {
            ci.cancel();
        }
    }
}
