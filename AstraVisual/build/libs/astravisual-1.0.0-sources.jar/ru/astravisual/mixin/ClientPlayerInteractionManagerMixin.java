package ru.astravisual.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.astravisual.module.ModuleManager;
import ru.astravisual.util.CombatTracker;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {

    @Inject(method = "attackEntity", at = @At("TAIL"))
    private void astravisual$attackEntity(class_1657 player, class_1297 target, CallbackInfo ci) {
        if (player != class_310.method_1551().field_1724) {
            return;
        }
        if (target instanceof class_1309 living) {
            CombatTracker.onAttack(living);
            if (ModuleManager.HIT_MARKER != null && ModuleManager.HIT_MARKER.isEnabled()) {
                ModuleManager.HIT_MARKER.onHit();
            }
        }
    }
}
