package ru.astravisual.module.hud;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_640;
import ru.astravisual.util.RenderUtil;
import ru.astravisual.util.Settings;

public final class PingModule extends HudModule {

    public PingModule() {
        super("Ping", "Server latency in milliseconds");
        setPosition(Anchor.TOP_LEFT, 4, 42);
    }

    private int ping() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.method_1562() == null) {
            return 0;
        }
        class_640 entry = client.method_1562().method_2871(client.field_1724.method_5667());
        return entry == null ? 0 : entry.method_2959();
    }

    private String value() {
        return ping() + "ms";
    }

    @Override
    public int width() {
        return RenderUtil.textWidth("PING") + RenderUtil.textWidth(value()) + 18;
    }

    @Override
    public int height() {
        return 14;
    }

    @Override
    public void render(class_332 ctx, int x, int y) {
        int ping = ping();
        int color = ping < 60 ? Settings.SUCCESS : ping < 130 ? Settings.WARN : Settings.DANGER;
        RenderUtil.panel(ctx, x, y, width(), height());
        RenderUtil.text(ctx, "PING", x + 8, y + 3, Settings.MUTED);
        RenderUtil.text(ctx, value(), x + 8 + RenderUtil.textWidth("PING") + 5, y + 3, color);
    }
}
