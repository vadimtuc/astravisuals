package ru.astravisual.module.hud;

import ru.astravisual.util.RenderUtil;
import ru.astravisual.util.Settings;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class PotionModule extends HudModule {

    private static final int WIDTH = 124;
    private static final int MAX_EFFECTS = 8;

    public PotionModule() {
        super("Potions", "Active status effects and timers");
        setPosition(Anchor.TOP_RIGHT, 4, 4);
    }

    private List<class_1293> effects() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return List.of();
        }
        List<class_1293> list = new ArrayList<>(client.field_1724.method_6026());
        list.sort(Comparator.comparingInt(class_1293::method_5584));
        if (list.size() > MAX_EFFECTS) {
            list = list.subList(0, MAX_EFFECTS);
        }
        return list;
    }

    @Override
    public int width() {
        return WIDTH;
    }

    @Override
    public int height() {
        int count = effects().size();
        return count == 0 ? 14 : 8 + count * 11;
    }

    @Override
    public void render(class_332 ctx, int x, int y) {
        List<class_1293> effects = effects();
        if (effects.isEmpty()) {
            RenderUtil.panel(ctx, x, y, width(), height());
            RenderUtil.text(ctx, "POTIONS", x + 8, y + 3, Settings.MUTED);
            RenderUtil.text(ctx, "—", x + width() - 12, y + 3, Settings.MUTED);
            return;
        }
        RenderUtil.panel(ctx, x, y, width(), height());
        for (int i = 0; i < effects.size(); i++) {
            class_1293 effect = effects.get(i);
            int rowY = y + 5 + i * 11;
            int color = effect.method_5579().comp_349().method_5556();
            if ((color & 0xFFFFFF) == 0) {
                color = Settings.ACCENT;
            }
            RenderUtil.rect(ctx, x + 7, rowY + 2, 4, 4, 0xFF000000 | color);

            String duration = effect.method_48559() ? "∞" : RenderUtil.formatDuration(effect.method_5584());
            int durationWidth = RenderUtil.textWidth(duration);
            String name = effect.method_5579().comp_349().method_5560().getString();
            if (effect.method_5578() > 0) {
                name += " " + roman(effect.method_5578() + 1);
            }
            int available = width() - 16 - durationWidth - 14;
            RenderUtil.text(ctx, RenderUtil.trim(name, available), x + 15, rowY, Settings.TEXT);
            RenderUtil.text(ctx, duration, x + width() - 8 - durationWidth, rowY, Settings.MUTED);
        }
    }

    private static String roman(int value) {
        return switch (value) {
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            default -> Integer.toString(value);
        };
    }
}
