package ru.astravisual.module.hud;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3966;
import ru.astravisual.util.ColorUtil;
import ru.astravisual.util.CombatTracker;
import ru.astravisual.util.RenderUtil;
import ru.astravisual.util.Settings;

public final class TargetHudModule extends HudModule {

    private static final int WIDTH = 132;

    public TargetHudModule() {
        super("Target HUD", "Health of the entity you are looking at");
        setPosition(Anchor.CENTER, 0, 56);
    }

    private class_1309 target() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return null;
        }
        if (client.field_1765 != null && client.field_1765.method_17783() == class_239.class_240.field_1331) {
            if (((class_3966) client.field_1765).method_17782() instanceof class_1309 living
                    && living != client.field_1724) {
                return living;
            }
        }
        class_1309 last = CombatTracker.getLastTarget();
        if (last != null && last != client.field_1724 && client.field_1724.method_5739(last) <= 8.0) {
            return last;
        }
        return null;
    }

    @Override
    public int width() {
        return WIDTH;
    }

    @Override
    public int height() {
        return target() == null ? 30 : 38;
    }

    @Override
    public void render(class_332 ctx, int x, int y) {
        class_1309 target = target();
        if (target == null) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return;
        }

        int width = width();
        int height = height();
        RenderUtil.panel(ctx, x, y, width, height);

        String name = target.method_5477().getString();
        String distance = String.format("%.1fm", client.field_1724.method_5739(target));
        int distanceWidth = RenderUtil.textWidth(distance);
        RenderUtil.text(ctx,
                RenderUtil.trim(name, width - 14 - distanceWidth - 10),
                x + 8,
                y + 5,
                target instanceof class_1657 ? Settings.TEXT : Settings.MUTED);
        RenderUtil.text(ctx, distance, x + width - 8 - distanceWidth, y + 5, Settings.MUTED);

        double max = Math.max(1.0, target.method_6063());
        double ratio = Math.max(0.0, Math.min(1.0, target.method_6032() / max));
        int barX = x + 7;
        int barY = y + 20;
        int barWidth = width - 14;
        RenderUtil.rect(ctx, barX, barY, barWidth, 5, 0xFF1F1F2A);
        RenderUtil.rect(ctx, barX, barY, Math.max(0, (int) Math.round(barWidth * ratio)), 5,
                ColorUtil.forRatio(ratio));

        String health = String.format("%.1f HP", target.method_6032());
        RenderUtil.text(ctx, health, x + 8, y + 27, Settings.TEXT);
        float absorption = target.method_6067();
        if (absorption > 0) {
            String absorptionText = String.format("+%.1f", absorption);
            RenderUtil.text(ctx, absorptionText, x + 8 + RenderUtil.textWidth(health) + 6, y + 27, Settings.WARN);
        }
        String maxHealth = "/ " + (int) max;
        RenderUtil.textRight(ctx, maxHealth, x + width - 8, y + 27, Settings.MUTED);
    }
}
