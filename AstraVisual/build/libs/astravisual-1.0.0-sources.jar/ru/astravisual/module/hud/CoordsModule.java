package ru.astravisual.module.hud;

import net.minecraft.class_2350;
import net.minecraft.class_310;
import net.minecraft.class_332;
import ru.astravisual.util.RenderUtil;
import ru.astravisual.util.Settings;

public final class CoordsModule extends HudModule {

    public CoordsModule() {
        super("Coords", "Player position and facing direction");
        setPosition(Anchor.TOP_LEFT, 4, 60);
    }

    private String values() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return "0 0 0";
        }
        return client.field_1724.method_31477() + " " + client.field_1724.method_31478() + " " + client.field_1724.method_31479();
    }

    private String facing() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return "N";
        }
        class_2350 direction = client.field_1724.method_5735();
        return switch (direction) {
            case field_11043 -> "N";
            case field_11035 -> "S";
            case field_11039 -> "W";
            case field_11034 -> "E";
            default -> "?";
        };
    }

    @Override
    public int width() {
        return RenderUtil.textWidth("XYZ") + RenderUtil.textWidth(values()) + RenderUtil.textWidth(facing()) + 24;
    }

    @Override
    public int height() {
        return 14;
    }

    @Override
    public void render(class_332 ctx, int x, int y) {
        RenderUtil.panel(ctx, x, y, width(), height());
        RenderUtil.text(ctx, "XYZ", x + 8, y + 3, Settings.MUTED);
        RenderUtil.text(ctx, values(), x + 8 + RenderUtil.textWidth("XYZ") + 5, y + 3, Settings.TEXT);
        RenderUtil.text(ctx,
                facing(),
                x + width() - RenderUtil.textWidth(facing()) - 8,
                y + 3,
                Settings.ACCENT);
    }
}
