package ru.astravisual.module.hud;

import ru.astravisual.util.ColorUtil;
import ru.astravisual.util.RenderUtil;
import ru.astravisual.util.Settings;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class ArmorModule extends HudModule {

    private static final class_1304[] SLOTS = {
            class_1304.field_6169,
            class_1304.field_6174,
            class_1304.field_6172,
            class_1304.field_6166,
            class_1304.field_6171
    };
    private static final int SLOT_SIZE = 18;

    public ArmorModule() {
        super("Armor", "Armor durability and offhand item");
        setPosition(Anchor.TOP_LEFT, 4, 184);
    }

    private List<class_1799> items() {
        class_310 client = class_310.method_1551();
        List<class_1799> result = new ArrayList<>();
        if (client.field_1724 == null) {
            return result;
        }
        for (class_1304 slot : SLOTS) {
            class_1799 stack = client.field_1724.method_6118(slot);
            if (!stack.method_7960()) {
                result.add(stack);
            }
        }
        return result;
    }

    @Override
    public int width() {
        int count = items().size();
        return count == 0 ? 54 : count * SLOT_SIZE + 4;
    }

    @Override
    public int height() {
        return items().isEmpty() ? 14 : 24;
    }

    @Override
    public void render(class_332 ctx, int x, int y) {
        List<class_1799> items = items();
        if (items.isEmpty()) {
            RenderUtil.panel(ctx, x, y, width(), height());
            RenderUtil.text(ctx, "ARMOR", x + 8, y + 3, Settings.MUTED);
            RenderUtil.text(ctx, "—", x + width() - 12, y + 3, Settings.MUTED);
            return;
        }
        RenderUtil.panel(ctx, x, y, width(), height());
        for (int i = 0; i < items.size(); i++) {
            class_1799 stack = items.get(i);
            int slotX = x + 3 + i * SLOT_SIZE;
            ctx.method_51427(stack, slotX, y + 3);
            if (stack.method_7963()) {
                int max = stack.method_7936();
                double ratio = max <= 0 ? 1.0 : 1.0 - (double) stack.method_7919() / max;
                int barColor = ColorUtil.forRatio(ratio);
                RenderUtil.rect(ctx, slotX, y + SLOT_SIZE + 1, 16, 2, 0xFF2A2A36);
                RenderUtil.rect(ctx, slotX, y + SLOT_SIZE + 1, Math.max(1, (int) Math.round(16 * ratio)), 2, barColor);
            }
        }
    }
}
