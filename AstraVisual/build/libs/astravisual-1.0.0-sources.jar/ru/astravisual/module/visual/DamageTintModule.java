package ru.astravisual.module.visual;

import net.minecraft.class_310;
import net.minecraft.class_332;
import ru.astravisual.util.ColorUtil;

public final class DamageTintModule extends VisualModule {

    private static final int RED = 0xFFB1121A;
    private static final int EDGE = 52;

    public DamageTintModule() {
        super("Damage Tint", "Red screen edges on damage and low health");
    }

    @Override
    public void renderOverlay(class_332 ctx) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return;
        }
        float strength = 0.0f;
        if (client.field_1724.field_6235 > 0) {
            strength = client.field_1724.field_6235 / 10.0f * 0.55f;
        }
        double max = Math.max(1.0, client.field_1724.method_6063());
        double ratio = client.field_1724.method_6032() / max;
        if (ratio < 0.35) {
            double pulse = (Math.sin(System.currentTimeMillis() / 320.0) + 1.0) / 2.0;
            float low = (float) ((0.35 - ratio) / 0.35) * (float) (0.16 + 0.14 * pulse);
            strength = Math.max(strength, low);
        }
        if (strength <= 0.01f) {
            return;
        }

        int width = client.method_22683().method_4486();
        int height = client.method_22683().method_4502();
        int solid = ColorUtil.withAlpha(RED, strength);
        int clear = ColorUtil.withAlpha(RED, 0.0f);

        ctx.method_25296(0, 0, width, EDGE, solid, clear);
        ctx.method_25296(0, height - EDGE, width, height, clear, solid);
        for (int i = 0; i < EDGE; i++) {
            int color = ColorUtil.withAlpha(RED, strength * (1.0f - i / (float) EDGE));
            ctx.method_25294(i, 0, i + 1, height, color);
            ctx.method_25294(width - 1 - i, 0, width - i, height, color);
        }
    }
}
