package ru.astravisual.util;

import net.minecraft.class_1309;
import net.minecraft.class_310;

/**
 * Keeps track of hit combos and the last entity the player attacked.
 */
public final class CombatTracker {

    private static final long TARGET_TIMEOUT_MS = 3000L;
    private static final long COMBO_TIMEOUT_MS = 2500L;

    private static int combo;
    private static long lastHitMs;
    private static class_1309 lastTarget;

    private CombatTracker() {
    }

    public static void onAttack(class_1309 target) {
        combo++;
        lastHitMs = System.currentTimeMillis();
        lastTarget = target;
    }

    public static void tick(class_310 client) {
        if (client.field_1724 == null) {
            reset();
            return;
        }
        if (combo > 0 && System.currentTimeMillis() - lastHitMs > COMBO_TIMEOUT_MS) {
            combo = 0;
        }
        if (client.field_1724.field_6235 == 10) {
            combo = 0;
        }
        if (lastTarget != null && !lastTarget.method_5805()) {
            lastTarget = null;
        }
    }

    public static int getCombo() {
        return combo;
    }

    public static class_1309 getLastTarget() {
        if (lastTarget == null || System.currentTimeMillis() - lastHitMs > TARGET_TIMEOUT_MS) {
            return null;
        }
        return lastTarget.method_5805() ? lastTarget : null;
    }

    public static void reset() {
        combo = 0;
        lastTarget = null;
    }
}
