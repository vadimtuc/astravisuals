package ru.astravisual.gui;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import ru.astravisual.config.ConfigManager;
import ru.astravisual.hud.HudManager;
import ru.astravisual.module.ModuleManager;
import ru.astravisual.module.hud.HudModule;
import ru.astravisual.util.ColorUtil;
import ru.astravisual.util.RenderUtil;
import ru.astravisual.util.Settings;

public final class HudEditorScreen extends class_437 {

    private HudModule dragging;
    private double grabX;
    private double grabY;

    public HudEditorScreen() {
        super(class_2561.method_43470("HUD Editor"));
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        context.method_25294(0, 0, field_22789, field_22790, 0x66000000);

        HudManager.renderModules(context);

        for (HudModule module : ModuleManager.HUD_MODULES) {
            int[] bounds = HudManager.bounds(module, field_22787);
            boolean hover = inside(mouseX, mouseY, bounds[0] - 4, bounds[1] - 4,
                    bounds[2] + 8, bounds[3] + 8);
            int color;
            if (!module.isEnabled()) {
                color = 0xFF4A4A58;
            } else if (dragging == module || hover) {
                color = 0xFFFFFFFF;
            } else {
                color = Settings.ACCENT;
            }
            RenderUtil.outline(context, bounds[0] - 1, bounds[1] - 1,
                    Math.max(2, bounds[2] + 2), Math.max(2, bounds[3] + 2), color);

            String label = module.getName() + (module.isEnabled() ? "" : " (off)");
            int labelY = bounds[1] - 10;
            if (labelY < 4) {
                labelY = bounds[1] + 2;
            }
            RenderUtil.text(context, label, bounds[0] + 1, labelY,
                    module.isEnabled() ? color : 0xFF9A9AA8);
        }

        String title = "HUD EDITOR";
        RenderUtil.textCenter(context, title, field_22789 / 2, 14, Settings.TEXT);
        String subtitle = "Drag elements · ESC — back to menu";
        RenderUtil.textCenter(context, subtitle, field_22789 / 2, 27, Settings.MUTED);

        drawResetButton(context, mouseX, mouseY);
    }

    private void drawResetButton(class_332 context, int mouseX, int mouseY) {
        int buttonWidth = 110;
        int buttonHeight = 22;
        int x = field_22789 / 2 - buttonWidth / 2;
        int y = field_22790 - 34;
        boolean hover = inside(mouseX, mouseY, x, y, buttonWidth, buttonHeight);
        RenderUtil.roundedRect(context, x, y, buttonWidth, buttonHeight, 5,
                ColorUtil.withAlpha(Settings.ACCENT, hover ? 0.30f : 0.18f));
        RenderUtil.textCenter(context, "Reset positions", x + buttonWidth / 2, y + 7, Settings.ACCENT);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int buttonWidth = 110;
            int buttonHeight = 22;
            int resetX = field_22789 / 2 - buttonWidth / 2;
            int resetY = field_22790 - 34;
            if (inside(mouseX, mouseY, resetX, resetY, buttonWidth, buttonHeight)) {
                ModuleManager.resetHudPositions();
                ConfigManager.save();
                return true;
            }

            for (int i = ModuleManager.HUD_MODULES.size() - 1; i >= 0; i--) {
                HudModule module = ModuleManager.HUD_MODULES.get(i);
                int[] bounds = HudManager.bounds(module, field_22787);
                if (inside(mouseX, mouseY, bounds[0] - 3, bounds[1] - 3,
                        Math.max(6, bounds[2] + 6), Math.max(6, bounds[3] + 6))) {
                    dragging = module;
                    grabX = mouseX - bounds[0];
                    grabY = mouseY - bounds[1];
                    return true;
                }
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging != null) {
            int[] bounds = HudManager.bounds(dragging, field_22787);
            int maxX = Math.max(0, field_22787.method_22683().method_4486() - bounds[2]);
            int maxY = Math.max(0, field_22787.method_22683().method_4502() - bounds[3]);
            int absoluteX = (int) Math.round(Math.max(0, Math.min(maxX, mouseX - grabX)));
            int absoluteY = (int) Math.round(Math.max(0, Math.min(maxY, mouseY - grabY)));
            HudManager.moveAbsolute(dragging, absoluteX, absoluteY, field_22787);
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (dragging != null) {
            dragging = null;
            ConfigManager.save();
            return true;
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public void method_25419() {
        ConfigManager.save();
        if (field_22787 != null) {
            field_22787.method_1507(new ClickGuiScreen());
        } else {
            super.method_25419();
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static boolean inside(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }
}
