package ru.astravisual.hud;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import ru.astravisual.module.ModuleManager;
import ru.astravisual.module.hud.Anchor;
import ru.astravisual.module.hud.HudModule;
import ru.astravisual.util.Settings;

public final class HudManager {

    private HudManager() {
    }

    public static void render(class_332 ctx) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }
        if (client.field_1690.field_1842) {
            return;
        }

        if (ModuleManager.DAMAGE_TINT.isEnabled()) {
            ModuleManager.DAMAGE_TINT.renderOverlay(ctx);
        }
        if (ModuleManager.CROSSHAIR.isEnabled()) {
            ModuleManager.CROSSHAIR.renderOverlay(ctx);
        }

        renderModules(ctx);

        if (ModuleManager.HIT_MARKER.isEnabled()) {
            ModuleManager.HIT_MARKER.renderOverlay(ctx);
        }
    }

    /** Renders only the HUD widgets (used by the editor to draw a crisp preview). */
    public static void renderModules(class_332 ctx) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1690.field_1842) {
            return;
        }
        for (HudModule module : ModuleManager.HUD_MODULES) {
            if (!module.isEnabled()) {
                continue;
            }
            int[] bounds = bounds(module, client);
            if (bounds[2] <= 0 || bounds[3] <= 0) {
                continue;
            }
            class_4587 matrices = ctx.method_51448();
            matrices.method_22903();
            matrices.method_22904(bounds[0], bounds[1], 0.0);
            matrices.method_22905(Settings.hudScale, Settings.hudScale, 1.0f);
            module.render(ctx, 0, 0);
            matrices.method_22909();
        }
    }

    /** Returns {x, y, width, height} in scaled screen coordinates. */
    public static int[] bounds(HudModule module, class_310 client) {
        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();
        float scale = Settings.hudScale;
        int width = Math.max(0, Math.round(module.width() * scale));
        int height = Math.max(0, Math.round(module.height() * scale));
        int x;
        int y;
        switch (module.getAnchor()) {
            case TOP_RIGHT -> {
                x = screenWidth - width - module.getOffsetX();
                y = module.getOffsetY();
            }
            case BOTTOM_LEFT -> {
                x = module.getOffsetX();
                y = screenHeight - height - module.getOffsetY();
            }
            case BOTTOM_RIGHT -> {
                x = screenWidth - width - module.getOffsetX();
                y = screenHeight - height - module.getOffsetY();
            }
            case CENTER -> {
                x = (screenWidth - width) / 2 + module.getOffsetX();
                y = (screenHeight - height) / 2 + module.getOffsetY();
            }
            default -> {
                x = module.getOffsetX();
                y = module.getOffsetY();
            }
        }
        return new int[]{x, y, width, height};
    }

    /** Moves an element so its absolute top-left corner is at the given position. */
    public static void moveAbsolute(HudModule module, int absoluteX, int absoluteY, class_310 client) {
        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();
        float scale = Settings.hudScale;
        int width = Math.max(0, Math.round(module.width() * scale));
        int height = Math.max(0, Math.round(module.height() * scale));
        switch (module.getAnchor()) {
            case TOP_RIGHT -> {
                module.setOffsetX(screenWidth - width - absoluteX);
                module.setOffsetY(absoluteY);
            }
            case BOTTOM_LEFT -> {
                module.setOffsetX(absoluteX);
                module.setOffsetY(screenHeight - height - absoluteY);
            }
            case BOTTOM_RIGHT -> {
                module.setOffsetX(screenWidth - width - absoluteX);
                module.setOffsetY(screenHeight - height - absoluteY);
            }
            case CENTER -> {
                module.setOffsetX(absoluteX - (screenWidth - width) / 2);
                module.setOffsetY(absoluteY - (screenHeight - height) / 2);
            }
            default -> {
                module.setOffsetX(absoluteX);
                module.setOffsetY(absoluteY);
            }
        }
    }
}
